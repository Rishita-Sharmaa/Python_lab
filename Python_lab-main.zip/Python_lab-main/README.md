# Python_lab
Python lab 5th sem
