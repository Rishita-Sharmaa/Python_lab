#Write a program to illustrate iteration over the list and dictionary.
# Iterating over a list
fruits = ["apple", "banana", "cherry", "date"]

print("Iterating over a list:")
for fruit in fruits:
    print(fruit)

# Iterating over a dictionary
student_scores = {"Alice": 95, "Bob": 89, "Charlie": 78, "David": 92}

print("\nIterating over a dictionary:")
for name, score in student_scores.items():
    print(f"{name}: {score}")
